var euAdat = [
    "Ausztria;1995.01.01",
    "Belgium;1958.01.01",
    "Bulgária;2007.01.01",
    "Ciprus;2004.05.01",
    "Csehország;2004.05.01",
    "Dánia;1973.01.01",
    "Egyesült Királyság;1973.01.01",
    "Észtország;2004.05.01",
    "Finnország;1995.01.01",
    "Franciaország;1958.01.01",
    "Görögország;1981.01.01",
    "Hollandia;1958.01.01",
    "Horvátország;2013.07.01",
    "Írország;1973.01.01",
    "Lengyelország;2004.05.01",
    "Lettország;2004.05.01",
    "Litvánia;2004.05.01",
    "Luxemburg;1958.01.01",
    "Magyarország;2004.05.01",
    "Málta;2004.05.01",
    "Németország;1958.01.01",
    "Olaszország;1958.01.01",
    "Portugália;1986.01.01",
    "Románia;2007.01.01",
    "Spanyolország;1986.01.01",
    "Svédország;1995.01.01",
    "Szlovákia;2004.05.01",
    "Szlovénia;2004.05.01",
];
function objFeltolto(orszagok) {
    var euOrszagok = [];
    for (var i = 0; i < orszagok.length; i++) {
        var adat = orszagok[i].split(";");
        var uj_orszag = {
            orszag_nev: adat[0],
            belepes_datum: adat[1]
        };
        euOrszagok.push(uj_orszag);
    }
    return euOrszagok;
}
var eu_orszag_adatok = objFeltolto(euAdat);
// console.log(eu_orszag_adatok);
// ========================= f01 Hány tagja van az EU-nak? =================================
var f1_tagok_szama_input = document.querySelector("#f1");
function f1_tagokszama() {
    return eu_orszag_adatok.length;
}
f1_tagok_szama_input.textContent = "Az EU-nak ".concat(f1_tagokszama(), " tagja van");
// ========================= f02 Hány ország csatlakozott az adott évben? =================================
var f2_csatlatlakozasEv = document.querySelector("#csatlatlakozasEv");
var f2_gomb = document.querySelector("#f2gomb");
var f2_eredmeny = document.querySelector("#f2");
function f2_hanyorszag() {
    var adott_ev = Number(f2_csatlatlakozasEv.value);
    var hany_orszag_csatlakozott = 0;
    for (var i = 0; i < eu_orszag_adatok.length; i++) {
        if (Number(eu_orszag_adatok[i].belepes_datum.split(".")[0]) == adott_ev) {
            hany_orszag_csatlakozott++;
        }
    }
    f2_eredmeny.textContent = "Ennyi orsz\u00E1g csatlakozott ".concat(adott_ev, " \u00E9vben: ").concat(hany_orszag_csatlakozott);
    // return hany_orszag_csatlakozott;
}
f2_gomb.addEventListener("click", f2_hanyorszag);
// ========================= f03 Csatlakozott-e adott ország az európai unióhoz? =================================
var f3_input = document.querySelector("#orszagNeve");
var f3_gomb = document.querySelector("#f3gomb");
var f3_eredmeny = document.querySelector("#f3");
function f3_csatlakozotte_adott_orszag() {
    var adott_orszag = f3_input.value;
    var csatlakozotte = "nem ";
    for (var i = 0; i < eu_orszag_adatok.length; i++) {
        if (eu_orszag_adatok[i].orszag_nev == adott_orszag) {
            csatlakozotte = "";
        }
    }
    f3_eredmeny.textContent = "".concat(adott_orszag, " ").concat(csatlakozotte, "csatlakozott az EU-hoz!");
}
f3_gomb.addEventListener("click", f3_csatlakozotte_adott_orszag);
// ========================= f04 Volt-e adott hónapban csatlakozás? =================================
var f4_input = document.querySelector("#honapAzonosito");
var f4_gomb = document.querySelector("#f4gomb");
var f4_eredmeny = document.querySelector("#f4");
function f4_adott_honap() {
    var adott_honap = Number(f4_input.value);
    var csatlakozotte = "nem ";
    for (var i = 0; i < eu_orszag_adatok.length; i++) {
        if (Number(eu_orszag_adatok[i].belepes_datum.split(".")[1]) == adott_honap) {
            csatlakozotte = "";
        }
    }
    f4_eredmeny.textContent = "A(z) ".concat(adott_honap, ". honapban ").concat(csatlakozotte, " volt csatlakoz\u00E1s az EU-hoz!");
}
f4_gomb.addEventListener("click", f4_adott_honap);
// ========================= f05 Ország Statisztika, melyik évben hány ország csatlakozott? =================================
