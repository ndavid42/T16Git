interface orszag {
    orszag_nev: string;
    belepes_datum: string;
}

var euAdat: string[] = [
    "Ausztria;1995.01.01",
    "Belgium;1958.01.01",
    "Bulgária;2007.01.01",
    "Ciprus;2004.05.01",
    "Csehország;2004.05.01",
    "Dánia;1973.01.01",
    "Egyesült Királyság;1973.01.01",
    "Észtország;2004.05.01",
    "Finnország;1995.01.01",
    "Franciaország;1958.01.01",
    "Görögország;1981.01.01",
    "Hollandia;1958.01.01",
    "Horvátország;2013.07.01",
    "Írország;1973.01.01",
    "Lengyelország;2004.05.01",
    "Lettország;2004.05.01",
    "Litvánia;2004.05.01",
    "Luxemburg;1958.01.01",
    "Magyarország;2004.05.01",
    "Málta;2004.05.01",
    "Németország;1958.01.01",
    "Olaszország;1958.01.01",
    "Portugália;1986.01.01",
    "Románia;2007.01.01",
    "Spanyolország;1986.01.01",
    "Svédország;1995.01.01",
    "Szlovákia;2004.05.01",
    "Szlovénia;2004.05.01",
];

function objFeltolto(orszagok: string[]): orszag[] {
    let euOrszagok: orszag[] = [];
    for (let i: number = 0; i < orszagok.length; i++) {
        let adat = orszagok[i].split(";");
        let uj_orszag: orszag = {
            orszag_nev: adat[0],
            belepes_datum: adat[1]
        }
        euOrszagok.push(uj_orszag);
    }

    return euOrszagok;
}

var eu_orszag_adatok = objFeltolto(euAdat);
// console.log(eu_orszag_adatok);


// ========================= f01 Hány tagja van az EU-nak? =================================
const f1_tagok_szama_input = document.querySelector("#f1") as HTMLParagraphElement;

function f1_tagokszama(): number {
    return eu_orszag_adatok.length;
}
f1_tagok_szama_input.textContent = `Az EU-nak ${f1_tagokszama()} tagja van`;


// ========================= f02 Hány ország csatlakozott az adott évben? =================================

const f2_csatlatlakozasEv = document.querySelector("#csatlatlakozasEv") as HTMLInputElement;
const f2_gomb = document.querySelector("#f2gomb") as HTMLButtonElement;
const f2_eredmeny = document.querySelector("#f2") as HTMLParagraphElement;


function f2_hanyorszag(): void {
    let adott_ev = Number(f2_csatlatlakozasEv.value);
    let hany_orszag_csatlakozott: number = 0;

    for (let i: number = 0; i < eu_orszag_adatok.length; i++) {
        if (Number(eu_orszag_adatok[i].belepes_datum.split(".")[0]) == adott_ev) {
            hany_orszag_csatlakozott++;
        }
    }

    f2_eredmeny.textContent = `Ennyi ország csatlakozott ${adott_ev} évben: ${hany_orszag_csatlakozott}`;

    // return hany_orszag_csatlakozott;
}

f2_gomb.addEventListener("click", f2_hanyorszag);


// ========================= f03 Csatlakozott-e adott ország az európai unióhoz? =================================
const f3_input = document.querySelector("#orszagNeve") as HTMLInputElement;
const f3_gomb = document.querySelector("#f3gomb") as HTMLButtonElement;
const f3_eredmeny = document.querySelector("#f3") as HTMLParagraphElement;

function f3_csatlakozotte_adott_orszag(): void {
    let adott_orszag = f3_input.value;
    let csatlakozotte: string = "nem ";

    for (let i: number = 0; i < eu_orszag_adatok.length; i++) {
        if (eu_orszag_adatok[i].orszag_nev == adott_orszag) {
            csatlakozotte = "";
        }
    }
    
    f3_eredmeny.textContent = `${adott_orszag} ${csatlakozotte}csatlakozott az EU-hoz!`;
}
f3_gomb.addEventListener("click", f3_csatlakozotte_adott_orszag);


// ========================= f04 Volt-e adott hónapban csatlakozás? =================================
const f4_input = document.querySelector("#honapAzonosito") as HTMLSelectElement;
const f4_gomb = document.querySelector("#f4gomb") as HTMLButtonElement;
const f4_eredmeny = document.querySelector("#f4") as HTMLParagraphElement;

function f4_adott_honap(): void {
    let adott_honap = Number(f4_input.value);
    let csatlakozotte: string = "nem ";

    for (let i: number = 0; i < eu_orszag_adatok.length; i++) {
        if (Number(eu_orszag_adatok[i].belepes_datum.split(".")[1]) == adott_honap) {
            csatlakozotte = "";
        }
    }
    
    f4_eredmeny.textContent = `A(z) ${adott_honap}. honapban ${csatlakozotte} volt csatlakozás az EU-hoz!`;
}
f4_gomb.addEventListener("click", f4_adott_honap);



// ========================= f05 Ország Statisztika, melyik évben hány ország csatlakozott? =================================