<?php
echo "működik!";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $veznev = $_POST["veznev"];
    $kernev = $_POST["kernev"];
    $email = $_POST["email"];
    $tel = $_POST["tel"];
    $beosztas = $_POST["beosztas"];

    // Display the submitted data
    echo "veznév: " . $veznev . "<br>";
    echo "kernév: " . $kernev . "<br>";
    echo "email: " . $email . "<br>";
    echo "tel: " . $tel . "<br>";
    echo "beosztás: " . $beosztas . "<br>";
}
?>