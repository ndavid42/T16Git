//1) Aktiváló gomb
aktivalo.addEventListener("click", mindenCheck);

function mindenCheck() {
    let elemLista = document.querySelectorAll(".allapot");
    for (let i = 0; i < elemLista.length; i++) {
        elemLista[i].checked = true;
    }
}
//2) Deaktiváló gomb
deaktivalo.addEventListener("click", mindenUnCheck);

function mindenUnCheck() {
    let elemLista = document.querySelectorAll(".allapot");
    for (let i = 0; i < elemLista.length; i++) {
        elemLista[i].checked = false;
    }
}

//Szorgalmi próbáld meg egy gomra rakni a két funkciót check/uncheck ALL, illetve megoldani, hogy meg is cserélje az elemeket.


//3) Táblázat sávozásának beállítása
savozasBe.addEventListener("click", SavozasBe);

function SavozasBe() {
    let kivalasztottTablazat = document.querySelector("table");
    kivalasztottTablazat.classList.add("table-striped");
}

//4) Táblázat sávozásának kikapcsolása
savozasKi.addEventListener("click", SavozasKi);
function SavozasKi() {
    let kivalasztottTablazat = document.querySelector("table");
    kivalasztottTablazat.classList.remove("table-striped");
}
//Szorgalmi próbáld meg egy gombra rakni a két funckiót sávozás ki-be


//5)Dark mode bekapcsolása
lightmode.addEventListener("click", LightMode);
function LightMode() {
    let kivalasztottTablazat = document.querySelector("table");
    kivalasztottTablazat.classList.add("table-light");
    kivalasztottTablazat.classList.remove("table-dark");
}

//6)Light mode bekapcsolása
darkmode.addEventListener("click", DarkMode);
function DarkMode() {
    let kivalasztottTablazat = document.querySelector("table");
    kivalasztottTablazat.classList.add("table-dark");
    kivalasztottTablazat.classList.remove("table-light");
}

//Szorgalmi: próbáld meg ki-be kapcsolhatóvá tenni a dark és light módokat.



//adatok feltöltése
//tesztsor

tesztsorBeszur.addEventListener("click", tesztsorBeszuras);

function tesztsorBeszuras() {
    let tabla = document.querySelector("#tablazat");
    let sor = tabla.insertRow();
    let veznevCella = sor.insertCell(0);
    let kernevCella = sor.insertCell(1);
    let emailCella = sor.insertCell(2);
    let telCella = sor.insertCell(3);
    let beosztasCella = sor.insertCell(4);
    let aktivalCella = sor.insertCell(5);
    let torolCella = sor.insertCell(6);

    veznevCella.innerHTML = "teszt vez";
    kernevCella.innerHTML = "teszt ker";
    emailCella.innerHTML = "teszt email";
    telCella.innerHTML = "teszt tel";
    beosztasCella.innerHTML = "teszt beoszt";
    aktivalCella.innerHTML = "<input type=\"checkbox\" class=\"allapot\">";
    torolCella.innerHTML = `<span class="row-del">❌</span>`;
    torolCella.firstElementChild.addEventListener("click", delete_this_row);
}


//adatok feltöltése
//űrlapadatok
ujelem.addEventListener("click", ujElemFeltolto);
ujelem2.addEventListener("click", ujElemFeltolto);

function ujElemFeltolto(){
    // if (is_form_submittable) {
        let tabla = document.getElementById("tablazat");
        let sor = tabla.insertRow();
        let veznevCella = sor.insertCell(0);
        let kernevCella = sor.insertCell(1);
        let emailCella = sor.insertCell(2);
        let telCella = sor.insertCell(3);
        let beosztasCella = sor.insertCell(4);
        let aktivalCella = sor.insertCell(5);
        let torolCella = sor.insertCell(6);

        veznevCella.innerHTML = document.querySelector("#veznev").value;
        kernevCella.innerHTML = document.querySelector("#kernev").value;
        emailCella.innerHTML = document.querySelector("#email").value;
        telCella.innerHTML = document.querySelector("#tel").value;
        beosztasCella.innerHTML = document.querySelector("#beosztas").value;
        aktivalCella.innerHTML = "<input type=\"checkbox\" class=\"allapot\">";
        torolCella.innerHTML = `<span class="row-del">❌</span>`;
        torolCella.firstElementChild.addEventListener("click", delete_this_row);
    // }
}


// szorg:
// validáció, regex. csak akkor tölti fel, ha jó
// email: pattern

del_buttons = document.getElementsByClassName("row-del");
for (let i = 0; i < del_buttons.length; i++) {
    del_buttons[i].addEventListener("click", delete_this_row);
}

function delete_this_row() {
    this.parentElement.parentElement.remove();
}


//validáció
input_elements = document.getElementsByClassName("form-control");

for(let i = 0; i < input_elements.length; i++) {
    input_elements[i].addEventListener("change", is_form_submittable);
}

function is_form_submittable() {
    let valid_inputs = 0;
    let is_form_submittable = false;
    for(let i = 0; i < input_elements.length; i++) {
        if (input_elements[i].required && input_elements[i].checkValidity()) {
            valid_inputs++;
        }
    }

    if (valid_inputs == input_elements.length) {
        is_form_submittable = true;
        ujelem.disabled = false;
    }

    console.log("req: " + input_elements[0].required);    
    console.log("val: " + input_elements[0].value == "");
    console.log("sub: " + is_form_submittable);

    return is_form_submittable
}