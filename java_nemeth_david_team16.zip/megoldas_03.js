/* 3) feladat
Készíts egy programot, ami egy adott intervallumban generál ki páros számot, és írjaki az értékét, a határétéket te magad állíthatod be,bekérés,alapján. */

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

let szam1 = Number(prompt("Intervallum ettől: "));
let szam2 = Number(prompt("Intervallum eddig: "));

document.write(`Páros számok a ${szam1} - ${szam2} intervallumban:<br />`);
for (let a = szam1; a <= szam2; a++) {
	if ((a%2) == 0) {
		document.write(`${a} `);
	}	
}