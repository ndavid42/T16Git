/* 1) feladat
Készíts egy olyan kódot mely kiírja az adott file készítőjének
•Nevét
•Csoportjának azonosítóját (melyik #Teamtagja)
•3.-4. és 5. sorpedig az legyen, mennyire érti a HTML, CSS és jelenlegi JavaScript tananyagokat1-100-ig(pl.: html:90) */

document.write(`Németh Dávid<br />`);
document.write(`Team16<br />`);
document.write(`HTML: 100<br />`);
document.write(`CSS: 100<br />`);
document.write(`JS: 100<br />`);