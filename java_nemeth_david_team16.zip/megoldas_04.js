// 4) feladat
/* Készíts egy programot, ami bekér egy életkort 1-120között és ennek függvényében megjeleníti az illető besorolását. 120 kor felettvagy 0 alatt, pedig hibát kapjunk!
Kisgyermekkor:0-6 év
Gyermekkor: 6-12 év
Serdülőkor: 12-16 év
Ifjúkor: 16-20 év
Fiatal felnőttkor: 20-30 év
Felnőttkor: 30-60
Aggkor: 60-tól */

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

let kor = Number(prompt("Életkor: "));

if ((kor > 120) || (kor < 0)) {
	document.write(`Hiba!`);
} else if (kor >= 60) {
	document.write(`Aggkor`);
} else if (kor >= 30) {
	document.write(`Felnőttkor`);
} else if (kor >= 20) {
	document.write(`Fiatal felnőttkor`);
} else if (kor >= 16) {
	document.write(`Ifjúkor`);
} else if (kor >= 12) {
	document.write(`Serdülőkor`);
} else if (kor >= 6) {
	document.write(`Gyermekkor`);
} else if (kor >= 0) {
	document.write(`Kisgyermekkor`);
}