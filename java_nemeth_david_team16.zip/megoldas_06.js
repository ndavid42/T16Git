// 6) feladat
// Készíts egy programot,ami kiírja az első 10 négyzetszámot!

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

for (let a = 1; a<=10; a++) {
	document.write((a*a) + `<br />`);
}