// 5) feladat
// Készíts egy olyan kódot, mely paraméterként bekér egy számot és egy osztót és kiírjaszövegesen,hogy az adott osztó, osztja-e az egész számot, úgy, hogy a maradék nulla.

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

let szam = Number(prompt("Szám: "));
let oszto = Number(prompt("Osztó: "));

if ((szam%oszto) == 0) {
	document.write(`A(z) ${oszto} maradék nélkül osztja a ${szam}-t, juhú!`);
} else {
	document.write(`A(z) ${oszto} nem osztja maradék nélkül a(z) ${szam}-t, maradék a(z) ` + szam%oszto);
}