/* 3) feladat
Készíts egy programot, ami egy adott intervallumban generál ki páros számot, és írjaki az értékét, a határétéket te magad állíthatod be,bekérés,alapján. */

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

let szam1 = Number(prompt("Intervallum ettől: "));
let szam2 = Number(prompt("Intervallum eddig: "));

genParos(szam1, szam2);

function genParos(szam1, szam2) { // min and max included 
	let rnd = -1;
	do {
		rnd = Math.floor(Math.random() * (szam2 - szam1 + 1) + szam1);
		/* document.write("nem páros: " + rnd + "<br />") */;
	} while ((rnd % 2) != 0)
	document.write(`Páros a ${szam1}-${szam2} határok között: ${rnd}`);
}