/* 2) feladat
Készíts egy olyan programot, mely bekér egy számot és a hatványozás mértékét, és kiírja annak hatványát.pl.: 2 és 3,azazkettő a harmadikon,azaz az eredmény 8 lesz! */

document.write(`Németh Dávid<br />`);
document.write(`Team16<br /><br />`);

let szam = Number(prompt("Szám: "));
let hatvany = Number(prompt("Hatvány: "));



let ertek = Math.pow(szam, hatvany);
document.write(`${szam} a(z) ${hatvany} hatványon az egyenlő ${ertek}`);